void applyPiorunEffect(vec2 uv, vec4 baseColor, vec4 effectColor, vec4 effectParams,
                      vec3 glyphT0, vec3 glyphT1, vec3 glyphT2, vec3 glyphT3,
                      float gameTime, sampler2D tex, out vec4 result) {
    float a = texture(tex, uv).a;
    if (a < 0.1) {
        discard;
    }

    vec2 uvMin, uvMax;
    calculateUVBounds(glyphT0, glyphT1, glyphT2, glyphT3, uvMin, uvMax);
    if (uvMax.x < uvMin.x || uvMax.y < uvMin.y) {
        uvMin = vec2(0.0);
        uvMax = vec2(1.0);
    }

    vec2 uvSize = uvMax - uvMin;
    float uNorm = (uvSize.x > 0.0001) ? (uv.x - uvMin.x) / uvSize.x : 0.5;
    float vNorm = (uvSize.y > 0.0001) ? (uv.y - uvMin.y) / uvSize.y : 0.5;

    float speed = max(effectParams.x, 0.1);
    float power = max(effectParams.y, 0.1);
    float t = gameTime * speed;
    float stepF = floor(t * 8.0);
    float seed = fract(sin(stepF * 12.9898 + 78.233) * 43758.5453);
    float flash = step(0.55, seed) * (0.5 + 0.5 * fract(seed * 7.0));
    float branch = step(0.7, fract(vNorm * 5.0 + seed * 10.0));
    vec3 color = baseColor.rgb + vec3(0.85, 0.92, 1.0) * flash * power * (0.8 + branch * 0.7);
    result = vec4(clamp(color, 0.0, 1.0), a * baseColor.a);
}
