void applyPerlaEffect(vec2 uv, vec4 baseColor, vec4 effectColor, vec4 effectParams,
                      vec3 glyphT0, vec3 glyphT1, vec3 glyphT2, vec3 glyphT3,
                      float gameTime, sampler2D tex, out vec4 result) {
    float a = texture(tex, uv).a;
    if (a < 0.1) {
        discard;
    }

    vec2 uvMin, uvMax;
    calculateUVBounds(glyphT0, glyphT1, glyphT2, glyphT3, uvMin, uvMax);
    if (uvMax.x < uvMin.x || uvMax.y < uvMin.y) {
        uvMin = vec2(0.0);
        uvMax = vec2(1.0);
    }

    vec2 uvSize = uvMax - uvMin;
    float uNorm = (uvSize.x > 0.0001) ? (uv.x - uvMin.x) / uvSize.x : 0.5;
    float vNorm = (uvSize.y > 0.0001) ? (uv.y - uvMin.y) / uvSize.y : 0.5;

    float speed = max(effectParams.x, 0.1);
    float iridescence = max(effectParams.y, 0.1);
    float t = gameTime * speed;
    float d = 0.7 * uNorm + 0.3 * vNorm;
    float p = fract(d - t * 0.3);
    float sheen = smoothstep(0.15, 0.45, p) * (1.0 - smoothstep(0.55, 0.85, p));
    float v2 = fract(p * 3.0 + 0.1);
    float rr = clamp(abs(v2 * 6.0 - 3.0) - 1.0, 0.0, 1.0);
    float gg = clamp(2.0 - abs(v2 * 6.0 - 2.0), 0.0, 1.0);
    float bb = clamp(2.0 - abs(v2 * 6.0 - 4.0), 0.0, 1.0);
    vec3 iri = vec3(rr, gg, bb) * iridescence;
    vec3 color = baseColor.rgb * (0.6 + sheen * 0.5) + (vec3(0.9, 0.92, 0.95) + iri * 0.5) * sheen * 1.1;
    result = vec4(clamp(color, 0.0, 1.0), a * baseColor.a);
}
