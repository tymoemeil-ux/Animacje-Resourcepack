void applyKaskadaEffect(vec2 uv, vec4 baseColor, vec4 effectColor, vec4 effectParams,
                      vec3 glyphT0, vec3 glyphT1, vec3 glyphT2, vec3 glyphT3,
                      float gameTime, sampler2D tex, out vec4 result) {
    float a = texture(tex, uv).a;
    if (a < 0.1) {
        discard;
    }

    vec2 uvMin, uvMax;
    calculateUVBounds(glyphT0, glyphT1, glyphT2, glyphT3, uvMin, uvMax);
    if (uvMax.x < uvMin.x || uvMax.y < uvMin.y) {
        uvMin = vec2(0.0);
        uvMax = vec2(1.0);
    }

    vec2 uvSize = uvMax - uvMin;
    float uNorm = (uvSize.x > 0.0001) ? (uv.x - uvMin.x) / uvSize.x : 0.5;
    float vNorm = (uvSize.y > 0.0001) ? (uv.y - uvMin.y) / uvSize.y : 0.5;

    float speed = max(effectParams.x, 0.1);
    float width = max(effectParams.y, 0.05);
    float t = gameTime * speed;
    float d = fract((1.0 - vNorm) + t * 0.8);
    float band = 1.0 - smoothstep(0.0, width * 2.0, d);
    float trail = exp(-d * 5.0) * 0.5;
    vec3 color = baseColor.rgb * 0.55 + vec3(0.7, 0.9, 1.0) * (band * 1.8 + trail);
    result = vec4(clamp(color, 0.0, 1.0), a * baseColor.a);
}
