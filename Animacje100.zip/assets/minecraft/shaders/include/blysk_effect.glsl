void applyBlyskEffect(vec2 uv, vec4 baseColor, vec4 effectColor, vec4 effectParams,
                      vec3 glyphT0, vec3 glyphT1, vec3 glyphT2, vec3 glyphT3,
                      float gameTime, sampler2D tex, out vec4 result) {
    float a = texture(tex, uv).a;
    if (a < 0.1) {
        discard;
    }

    vec2 uvMin, uvMax;
    calculateUVBounds(glyphT0, glyphT1, glyphT2, glyphT3, uvMin, uvMax);
    if (uvMax.x < uvMin.x || uvMax.y < uvMin.y) {
        uvMin = vec2(0.0);
        uvMax = vec2(1.0);
    }

    vec2 uvSize = uvMax - uvMin;
    float uNorm = (uvSize.x > 0.0001) ? (uv.x - uvMin.x) / uvSize.x : 0.5;
    float vNorm = (uvSize.y > 0.0001) ? (uv.y - uvMin.y) / uvSize.y : 0.5;

    float speed = max(effectParams.x, 0.1);
    float width = max(effectParams.y, 0.05);
    float t = gameTime * speed;
    float d = 0.6 * uNorm + 0.4 * vNorm;
    float p = fract(d - t * 0.6);
    float flash = 1.0 - smoothstep(0.0, width, p);
    float tail = (1.0 - smoothstep(0.0, width * 6.0, p)) * 0.35;
    vec3 color = baseColor.rgb * 0.6 + vec3(0.85, 0.93, 1.0) * (flash * 1.8 + tail);
    result = vec4(clamp(color, 0.0, 1.0), a * baseColor.a);
}
