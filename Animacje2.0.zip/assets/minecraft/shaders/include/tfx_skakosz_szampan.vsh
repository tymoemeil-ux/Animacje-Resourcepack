// ============================================================
// EFEKT (polaczenie: ruch skakosz + kolor szampan): SKAKOSZ_SZAMPAN   |   kolor spustowy: #60D048
// skakosz_szampan
// ============================================================
if (c == ivec3(96, 208, 72)) {
        tfxIDg = 204.0;

    float ph = fract(GameTime * 1.6 + g * 0.13);
    float b = sin(min(ph / 0.45, 1.0) * 3.14159);
    tfxOffg.y -= b * b * 0.026;
    tfxOffg.x += (b - 0.5) * 0.004;
}
