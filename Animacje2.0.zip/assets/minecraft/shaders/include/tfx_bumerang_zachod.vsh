// ============================================================
// EFEKT (polaczenie: ruch bumerang + kolor zachod): BUMERANG_ZACHOD   |   kolor spustowy: #60D038
// bumerang_zachod
// ============================================================
if (c == ivec3(96, 208, 56)) {
        tfxIDg = 200.0;

    float t = GameTime * 1.4;
    float w = sin(t + g * 0.5);
    tfxOffg.x += w * 0.014;
    tfxOffg.y -= abs(w) * 0.018;
}
